# ClassPlaner
A college management system built using Django framework. It is designed for interactions between students and teachers. Features include attendance, marks and time table.
